import { Component, OnInit, ViewChildren, ElementRef } from '@angular/core';   
import {CommonService} from '../common.service';    

@Component({  
  selector: 'app-root',  
  templateUrl: './app.component.html',  
  styleUrls: ['./app.component.css']  
})  
export class AppComponent 
{  
  constructor(private newService :CommonService,) {   }  
  Repdata;  
  avg_salary;
  valbutton ="Save"; 
  sort_by;
   
  ngOnInit() 
  {   
    this.newService.GetUser(this.sort_by).subscribe(data =>  this.Repdata = data)
    this.newService.emp_Avg().subscribe(
    data =>  this.avg_salary = data) 
  }  
  onSave = function(emp,isValid: boolean) 
  {    
    emp.mode= this.valbutton; 
    if(emp.name==null||emp.name==""||!isNaN(emp.name))
    {
      //alert("Name is required");
      this.error="Please Provide Valid Name";
    }
    else if(emp.salary==null||emp.salary==""||emp.salary<1||emp.salary.toString().length>20) 
    {
      //alert("salary is required");
      this.error="Please Provide Valid Salary";
    }
    else if(emp.emp_type==null||emp.emp_type=="") 
    {
      //alert("Please select Employee Type");
      this.error="Please select Employee Type";
    }
    else
    {
      this.error="";
      this.newService.saveUser(emp)  .subscribe(
        data =>  {  alert(data.data);
        this.ngOnInit();    
      }   , error => this.errorMessage = error );  
    }   
  }  
  getuser = function(dt)
  {  
    
    this.sort_by=dt;
    this.newService.GetUser(this.sort_by).subscribe(data =>   {this.Repdata = data  ; this.ngOnInit();}, error => this.errorMessage = error )
    
  }    
  edit = function(kk) 
  {  
    this.id = kk._id;  
    this.name= kk.name;  
    this.salary= kk.salary;
    this.emp_type= kk.emp_type;  
    this.valbutton ="Update";  
  }  
  delete = function(id) 
  {  
    this.newService.deleteUser(id).subscribe(data =>   { alert(data.data) ; this.ngOnInit();}, error => this.errorMessage = error )   
  }  
}