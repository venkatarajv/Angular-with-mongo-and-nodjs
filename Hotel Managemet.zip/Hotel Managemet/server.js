var express = require('express');  
var path = require("path");   
var bodyParser = require('body-parser');  
var mongo = require("mongoose");  
  
var db = mongo.connect("mongodb://localhost:27017/mydb", 
function(err, response)
{  
   if(err){ console.log( err); }  
   else{ console.log('Connected to ' + db); }  
});  
  
var app = express()  
app.use(bodyParser());  
app.use(bodyParser.json({limit:'5mb'}));   
app.use(bodyParser.urlencoded({extended:true}));  
  
app.use(function (req, res, next) {        
     res.setHeader('Access-Control-Allow-Origin', 'http://localhost:4200');    
     res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');    
     res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');      
     res.setHeader('Access-Control-Allow-Credentials', true);    
     next();  
 });  
  
var Schema = mongo.Schema;   
var UsersSchema = new Schema({      
 name: { type: String   },       
 salary: { type: Number   },
 emp_type: { type: Number   },   
},{ versionKey: false });  
   
  
var model = mongo.model('employee', UsersSchema, 'employee');  

app.post("/api/SaveUser",function(req,res)
{   
  var mod = new model(req.body);  
  if(req.body.mode =="Save")  
  {  
    mod.save(function(err,data)
    {  
      if(err)
      {  
        res.send(err);                
      }  
      else
      {       
        res.send({data:"Record has been Inserted..!!"});
          
      }  
    });  
  }  
  else   
  {  
    model.findByIdAndUpdate(req.body.id, { name: req.body.name, salary: req.body.salary,emp_type:req.body.emp_type},  
    function(err,data) 
    {  
      if (err) 
      {  
        res.send(err);         
      }  
      else
      {       
        res.send({data:"Record has been Updated..!!"});  
      }  
    });   
  }  
})  
  
app.post("/api/deleteUser",function(req,res)
{      
  model.remove({ _id: req.body.id }, function(err) 
  {    
    if(err)
    {    
      res.send(err);    
    }    
    else
    {      
      res.send({data:"Record has been Deleted..!!"});       
    }    
  });    
})  
  
app.post("/api/getUser",function(req,res)
{  
  var js_sort_type=req.body.sort_by==2?-1:1;
  model.find().sort({salary:js_sort_type}).exec(
  function(err,data)
  {  
    if(err)
    {  
      res.send(err);  
    }  
    else
    {                
      res.send(data);  
    }  
  });  
}) 

app.get("/api/emp_avg",function(req,res)
{
  model.aggregate([
  { "$match": {
  "emp_type": { "$eq": 1 }
  }},
  { "$group": {
  "_id": "",
  "avg_salary": { "$avg": "$salary" }
  }}],
  function(err,data)
  {
    if(err)
    {  
      res.send(err);  
    }  
    else
    {                
      res.send(data);  
    }  
  })
});  

app.listen(8080, function ()
{  
 console.log('Example app listening on port 8080!')  
})  